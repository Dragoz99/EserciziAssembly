#####################################################################################
LABORATORIO INTERDISIPINARE A (2018/2019)
-------------------------------------------------------------------------------------
EserciziAssembly_737854

data di consegna: 10/04/2019
#####################################################################################

gruppo di lavoro:
Angella Lorenzo	737854
Frontini Luca	738864
Frattini Gaia   736610
Giuseppe Mattia Galbiati 737533
Peter Saliman   738650
		

file:
	  -EserciziAssembly_#737853.zip 
             |
	     |-> Esponente.s          				sha256:DFD1E6B52C0033A19CD4858A87441A12974E22FB7A1D880AA6DC815641854C3D
	     |
	     |-> finbonacci.s          				sha256:FC55E264E21F6D0DE661C76AB309377E9891D9916B48B177BC8F1F29C685C208
	     |
	     |-> Maggiore.s          				sha256:BD4A4A4C559C88A3CA67037D3124BA87621E28C422846969803AB91EBBCFF96F
	     |
	     |-> Media1.s          				sha256:114A5D02192E34F367BF76228E08DD248234DB230FC70CC6C413DCEF523A0260
	     |
	     |-> Stringaimproved.s          			sha256:631C5859BD3438BC0EB797524A8048CA986E836F7A7FB7764D5081FC1774F60D
	     |
	     |-> README.txt          				
	     |
	     |-> SVILUPPATORE - SOFTWARE DI CALCOLO1.pdf        sha256:DBC63AD67553BE0D4BF5127006269808931B8F3511F6F5F263A3146218E83971
             |
	     |-> UTENTE - SOFTWARE DI CALCOLO.pdf          	sha256:7C8549377BA31DD13175EE6CFBCE55D30989E81A22E789D69EBE10EBB0EDE8EC
	     